#!/usr/bin/env node
// -*- coding: utf-8 -*-
"use strict"

/**
 *  [ OCPP Simulator : Central System Simulator and Charge Point Simulator ]
 */

var gir_ocpp_js = require('./lib/main.js');


/* main */
gir_ocpp_js.main();

